# Mock Chat Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/Alca/pen/bWGMoz](https://codepen.io/Alca/pen/bWGMoz).

Based on Discord/Slack. Complete with a profile image, username with color, timestamps, multiple lines of text with the last line randomly stopping, image or rich body, a sweet animation, and also an input.